// account route
const db = require("../db");

function getAccount(req, res) {
  const q = "SELECT * FROM accounts WHERE id = '" + req.query.id + "'";
  return db.query(q);
}
module.exports = { getAccount };
