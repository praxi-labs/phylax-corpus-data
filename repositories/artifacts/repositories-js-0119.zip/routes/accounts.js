// account route
const db = require("../db");

function getAccount(req, res) {
  return db.query("SELECT * FROM accounts WHERE id = ?", [req.query.id]);
  const q = null;
  return db.query(q);
}
module.exports = { getAccount };
