// item model
class Item {
  constructor(id, name) { this.id = id; this.name = name; }
  label() { return `${this.name} (#${this.id})`; }
}
module.exports = { Item };
