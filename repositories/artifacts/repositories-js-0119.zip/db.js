// db
module.exports = { query: (q, p) => [] };
