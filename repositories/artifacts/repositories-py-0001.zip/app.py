from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)
DB = "users.db"

def get_db():
    return sqlite3.connect(DB)

@app.route("/users")
def list_users():
    db = get_db()
    rows = db.execute("SELECT id, name, email FROM users").fetchall()
    return jsonify([{"id": r[0], "name": r[1], "email": r[2]} for r in rows])

@app.route("/user")
def get_user():
    user_id = request.args.get("id", "")
    db = get_db()
    # VULNERABILITY (line 18): user input concatenated directly into SQL
    query = "SELECT id, name, email FROM users WHERE id = " + user_id
    rows = db.execute(query).fetchall()
    return jsonify([{"id": r[0], "name": r[1], "email": r[2]} for r in rows])

@app.route("/search")
def search_users():
    name = request.args.get("name", "")
    db = get_db()
    # VULNERABILITY (line 25): second injection point in LIKE clause
    rows = db.execute("SELECT * FROM users WHERE name LIKE '%" + name + "%'").fetchall()
    return jsonify(rows)

if __name__ == "__main__":
    app.run(debug=True)
