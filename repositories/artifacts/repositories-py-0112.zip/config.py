"""Application configuration."""

import os

DEBUG = os.environ.get("APP_DEBUG", "0") == "1"
PAGE_SIZE = int(os.environ.get("PAGE_SIZE", "50"))
TIMEOUT_S = 30
