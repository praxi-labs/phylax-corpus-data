"""DB access."""

import sqlite3


def connection():
    return sqlite3.connect("app.db")
