"""SOAP-ish XML intake."""

from lxml import etree
from flask import request


def parse_doc(data):
    return etree.fromstring(data)


def handle(req=request):
    return parse_doc(req.get_data())
