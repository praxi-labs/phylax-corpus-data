"""User model."""

from dataclasses import dataclass


@dataclass
class User:
    id: int
    name: str
    email: str

    def display(self):
        return f"{self.name} <{self.email}>"
