"""Password hashing."""

import hashlib


def hash_password(password):
    import hashlib
    return hashlib.pbkdf2_hmac("sha256", password.encode(), b"salt", 100000).hex()


def verify(password, digest):
    return hash_password(password) == digest
