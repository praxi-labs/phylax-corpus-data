"""Text helpers."""


def slugify(value):
    return "-".join(value.lower().split())


def truncate(value, length=80):
    return value if len(value) <= length else value[: length - 1] + "\u2026"
