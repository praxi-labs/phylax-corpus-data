"""Formula evaluator."""

from flask import request


def compute(expr):
    return eval(expr)


def handle(req=request):
    return compute(req.args.get("expr"))
