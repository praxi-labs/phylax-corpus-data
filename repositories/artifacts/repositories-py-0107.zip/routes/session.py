"""Session decoder."""

import pickle
from flask import request


def load_session(blob):
    import json
    return json.loads(blob)


def handle(req=request):
    return load_session(req.get_data())
