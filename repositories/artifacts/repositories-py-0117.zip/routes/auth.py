"""Login redirect."""

from flask import request, redirect


def after_login(next_url):
    target = next_url if next_url.startswith("/") else "/"
    return redirect(target)


def handle(req=request):
    return after_login(req.args.get("next", "/"))
