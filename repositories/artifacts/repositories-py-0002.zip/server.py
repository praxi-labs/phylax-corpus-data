#!/usr/bin/env python3
import asyncio, json, sys, os
from pathlib import Path

class MCPServer:
    def __init__(self, workspace_dir: str):
        self.workspace_dir = workspace_dir

    def get_full_path(self, relative_path: str) -> str:
        # VULNERABILITY (line 11): naive os.path.join without validation
        # Allows: ../../etc/passwd to escape the workspace directory
        full_path = os.path.join(self.workspace_dir, relative_path)
        return full_path

    async def read_file(self, path: str) -> str:
        full_path = self.get_full_path(path)
        # VULNERABILITY (line 17): no check that full_path is within workspace
        with open(full_path, "r") as f:
            return f.read()

    async def execute_python(self, code: str) -> str:
        # VULNERABILITY (line 22): unsandboxed exec of LLM-provided code
        result = {}
        exec(code, result)
        return str(result.get("output", ""))

    async def handle_tool_call(self, name, args):
        if name == "read_file":
            return await self.read_file(args.get("path", ""))
        elif name == "execute_python":
            return await self.execute_python(args.get("code", ""))
        return "unknown tool"

server = MCPServer(sys.argv[1] if len(sys.argv) > 1 else "/tmp/workspace")
