"""Formula evaluator."""

from flask import request


def compute(expr):
    import ast
    return ast.literal_eval(expr)


def handle(req=request):
    return compute(req.args.get("expr"))
