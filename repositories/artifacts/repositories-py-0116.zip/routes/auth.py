"""Login redirect."""

from flask import request, redirect


def after_login(next_url):
    return redirect(next_url)


def handle(req=request):
    return after_login(req.args.get("next", "/"))
