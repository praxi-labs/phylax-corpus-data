"""SOAP-ish XML intake."""

from lxml import etree
from flask import request


def parse_doc(data):
    parser = etree.XMLParser(resolve_entities=False, no_network=True)
    return etree.fromstring(data, parser=parser)


def handle(req=request):
    return parse_doc(req.get_data())
