"""Static file server."""

import os
from flask import request

BASE = "/srv/files"


def read_file(name):
    safe = os.path.basename(name)
    path = os.path.join(BASE, safe)
    with open(path, "rb") as fh:
        return fh.read()


def handle(req=request):
    return read_file(req.args.get("name"))
