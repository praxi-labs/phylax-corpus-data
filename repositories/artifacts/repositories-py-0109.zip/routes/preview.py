"""URL preview service."""

import requests
from flask import request


def fetch(url):
    from urllib.parse import urlparse
    if urlparse(url).hostname not in ("api.internal",):
        raise ValueError("host not allowed")
    return requests.get(url, timeout=5).text


def handle(req=request):
    return fetch(req.args.get("url"))
