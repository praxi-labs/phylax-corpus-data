"""URL preview service."""

import requests
from flask import request


def fetch(url):
    return requests.get(url, timeout=5).text


def handle(req=request):
    return fetch(req.args.get("url"))
