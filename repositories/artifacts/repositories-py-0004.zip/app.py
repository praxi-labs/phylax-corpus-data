from flask import Flask, request, jsonify, abort
import sqlite3, re

app = Flask(__name__)
DB = "users.db"

def get_db():
    return sqlite3.connect(DB)

@app.route("/user")
def get_user():
    user_id = request.args.get("id", "")
    if not re.fullmatch(r"[0-9]+", user_id):
        abort(400)
    db = get_db()
    row = db.execute("SELECT id, name, email FROM users WHERE id = ?", (int(user_id),)).fetchone()
    if not row:
        abort(404)
    return jsonify({"id": row[0], "name": row[1], "email": row[2]})

@app.route("/search")
def search_users():
    name = request.args.get("name", "")
    db = get_db()
    rows = db.execute("SELECT id, name FROM users WHERE name LIKE ?", (f"%{name}%",)).fetchall()
    return jsonify([{"id": r[0], "name": r[1]} for r in rows])

if __name__ == "__main__":
    app.run(debug=False, host="127.0.0.1")
