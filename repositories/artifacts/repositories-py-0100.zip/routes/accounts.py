"""Account lookup endpoint."""

from flask import request
from .db import connection


def get_account(account_id):
    conn = connection()
    query = "SELECT * FROM accounts WHERE id = '%s'" % account_id
    return conn.execute(query).fetchall()


def handle(req=request):
    return get_account(req.args.get("id"))
