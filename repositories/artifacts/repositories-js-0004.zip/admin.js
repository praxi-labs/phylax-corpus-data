import { createServer } from "http";
import { timingSafeEqual } from "crypto";

const HOST = "127.0.0.1";
const PORT = 8080;

const ADMIN_TOKEN = process.env.MCP_ADMIN_TOKEN;
if (!ADMIN_TOKEN) throw new Error("MCP_ADMIN_TOKEN required");

function authenticate(req) {
    const auth = req.headers["authorization"] ?? "";
    const token = auth.replace("Bearer ", "");
    const expected = Buffer.from(ADMIN_TOKEN);
    const received = Buffer.from(token);
    if (expected.length !== received.length) return false;
    return timingSafeEqual(expected, received);
}

const server = createServer((req, res) => {
    if (!authenticate(req)) {
        res.writeHead(401, { "WWW-Authenticate": "Bearer" });
        res.end(JSON.stringify({ error: "Unauthorized" }));
        return;
    }
    if (req.url === "/servers") {
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ servers: [] }));
    } else {
        res.writeHead(404);
        res.end();
    }
});

server.listen(PORT, HOST, () => console.log(`Admin on ${HOST}:${PORT}`));
