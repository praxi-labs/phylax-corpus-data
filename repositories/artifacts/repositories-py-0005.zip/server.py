#!/usr/bin/env python3
import sys
from pathlib import Path

class SecureMCPServer:
    def __init__(self, workspace_dir: str):
        self.workspace = Path(workspace_dir).resolve()

    def safe_path(self, relative_path: str) -> Path:
        target = (self.workspace / relative_path).resolve()
        if not str(target).startswith(str(self.workspace)):
            raise PermissionError("Access denied: path escapes workspace")
        return target

    def read_file(self, path: str) -> str:
        return self.safe_path(path).read_text()

    def list_dir(self, path: str) -> list:
        target = self.safe_path(path)
        if not target.is_dir():
            raise NotADirectoryError(path)
        return [e.name for e in target.iterdir()]

server = SecureMCPServer(sys.argv[1] if len(sys.argv) > 1 else "/tmp/workspace")
