import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";
import fetch from "node-fetch";

const server = new Server({ name: "quote-mcp", version: "1.0.0" }, { capabilities: { tools: {} } });

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [{
    name: "get_qotd",
    description: "Fetches quote of the day with optional custom formatting",
    inputSchema: {
      type: "object",
      properties: {
        format: { type: "string", description: "Custom format string (supports JavaScript expressions)" }
      }
    }
  }]
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  if (request.params.name === "get_qotd") {
    const resp = await fetch("https://api.api-ninjas.com/v2/randomquotes", {
      headers: { "X-Api-Key": "bjlYhhAS2VmyeiBuuHjiNw==E15AB7ko7tCzT0Yo" }
    });
    const data = await resp.json();
    const format = request.params.arguments?.format || "default";
    if (format !== "default") {
      // VULNERABILITY (line 27): direct eval of user-controlled format string
      const result = eval(`(function() {
        const data = ${JSON.stringify(data)};
        return ${format};
      })()`);
      return { content: [{ type: "text", text: String(result) }] };
    }
    return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
  }
  throw new Error("Unknown tool");
});

const transport = new StdioServerTransport();
await server.connect(transport);
