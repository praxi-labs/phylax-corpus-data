#!/usr/bin/env python3
import json, subprocess, sys
from http.server import HTTPServer, BaseHTTPRequestHandler

# VULNERABILITY (line 6): binds on all interfaces instead of 127.0.0.1
BIND_HOST = "0.0.0.0"
BIND_PORT = 8080

INSTALLED_SERVERS = {}

class AdminHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/servers":
            # VULNERABILITY (line 14): no authentication check before listing
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(INSTALLED_SERVERS).encode())
        elif self.path.startswith("/install"):
            # VULNERABILITY (line 21): no authentication before executing install
            server_url = self.path.split("?url=")[-1]
            result = subprocess.run(
                ["npm", "install", "-g", server_url],
                capture_output=True, text=True
            )
            self.send_response(200)
            self.end_headers()
            self.wfile.write(result.stdout.encode())
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        pass

if __name__ == "__main__":
    server = HTTPServer((BIND_HOST, BIND_PORT), AdminHandler)
    print(f"Admin panel on {BIND_HOST}:{BIND_PORT} (no auth)")
    server.serve_forever()
