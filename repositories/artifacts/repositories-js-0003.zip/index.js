import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";

// Credentials from environment only
const API_KEY = process.env.QUOTE_API_KEY;
if (!API_KEY) throw new Error("QUOTE_API_KEY environment variable required");

const server = new Server({ name: "quote-mcp-secure", version: "2.0.0" }, { capabilities: { tools: {} } });

const ALLOWED_FORMATS = ["json", "plain", "markdown"];

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [{
    name: "get_qotd",
    description: "Fetches a quote of the day",
    inputSchema: {
      type: "object",
      properties: {
        format: { type: "string", enum: ["json", "plain", "markdown"] }
      }
    }
  }]
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  if (request.params.name === "get_qotd") {
    const format = request.params.arguments?.format ?? "json";
    if (!ALLOWED_FORMATS.includes(format)) throw new Error("Invalid format");
    const data = { quote: "Safe and clean", author: "Secure Dev" };
    const text = format === "json" ? JSON.stringify(data) : `${data.quote} — ${data.author}`;
    return { content: [{ type: "text", text }] };
  }
  throw new Error("Unknown tool");
});

const transport = new StdioServerTransport();
await server.connect(transport);
