"""Diagnostics endpoint."""

import subprocess
from flask import request


def ping(host):
    return subprocess.check_output("ping -c1 " + host, shell=True)


def handle(req=request):
    return ping(req.args.get("host"))
