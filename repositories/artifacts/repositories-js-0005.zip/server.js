import express from "express";
import { z } from "zod";

const app = express();
app.use(express.json());

const UserQuery = z.object({ id: z.coerce.number().int().positive() });
const SearchQuery = z.object({ name: z.string().min(1).max(100) });

app.get("/user", async (req, res) => {
    const parse = UserQuery.safeParse(req.query);
    if (!parse.success) return res.status(400).json({ error: parse.error });
    res.json({ id: parse.data.id, name: "example" });
});

app.get("/search", async (req, res) => {
    const parse = SearchQuery.safeParse(req.query);
    if (!parse.success) return res.status(400).json({ error: parse.error });
    res.json({ results: [] });
});

app.listen(3000, "127.0.0.1");
