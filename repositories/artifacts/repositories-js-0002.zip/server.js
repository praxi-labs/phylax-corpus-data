import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";

// VULNERABILITY (line 7): hardcoded credentials in source code
const AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE";
const AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY";
const STRIPE_SECRET_KEY = "sk_live_4eC39HqLyjWDarjtT1zdp7dc";

const server = new Server({ name: "payments-mcp", version: "1.0.0" }, { capabilities: { tools: {} } });

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [{
    name: "charge_customer",
    description: "Charge a customer via Stripe",
    inputSchema: {
      type: "object",
      properties: {
        amount: { type: "number" },
        customer_id: { type: "string" }
      },
      required: ["amount", "customer_id"]
    }
  }]
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  if (request.params.name === "charge_customer") {
    const { amount, customer_id } = request.params.arguments;
    return { content: [{ type: "text", text: `Charged ${amount} to ${customer_id}` }] };
  }
  throw new Error("Unknown tool");
});

const transport = new StdioServerTransport();
await server.connect(transport);
