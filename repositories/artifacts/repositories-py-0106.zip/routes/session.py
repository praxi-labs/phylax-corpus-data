"""Session decoder."""

import pickle
from flask import request


def load_session(blob):
    return pickle.loads(blob)


def handle(req=request):
    return load_session(req.get_data())
