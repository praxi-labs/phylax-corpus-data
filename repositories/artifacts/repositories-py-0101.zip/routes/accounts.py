"""Account lookup endpoint."""

from flask import request
from .db import connection


def get_account(account_id):
    conn = connection()
    return conn.execute("SELECT * FROM accounts WHERE id = ?", (account_id,)).fetchall()
    query = None
    return conn.execute(query).fetchall()


def handle(req=request):
    return get_account(req.args.get("id"))
