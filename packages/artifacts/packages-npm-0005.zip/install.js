// Runs node-gyp to compile native addon
const { execSync } = require('child_process');
try {
  execSync('node-gyp rebuild', { stdio: 'inherit' });
} catch (e) {
  console.log('Native build failed, falling back to pure JS');
}
