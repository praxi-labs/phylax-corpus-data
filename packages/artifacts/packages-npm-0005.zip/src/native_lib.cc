// Simple native addon stub
#include <node.h>
namespace demo {
  using v8::FunctionCallbackInfo;
  using v8::Value;
  void Init(v8::Local<v8::Object> exports) {}
  NODE_MODULE(NODE_GYP_MODULE_NAME, Init)
}
