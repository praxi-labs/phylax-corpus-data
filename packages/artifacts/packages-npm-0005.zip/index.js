// Load native addon or fall back to pure-JS implementation
let native;
try {
  native = require('./build/Release/native_lib.node');
} catch (_) {
  native = require('./lib/fallback');
}
module.exports = native;
