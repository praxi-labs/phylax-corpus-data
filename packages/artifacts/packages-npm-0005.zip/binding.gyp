{
  "targets": [
    {
      "target_name": "native_lib",
      "sources": [
        "src/native_lib.cc"
      ]
    }
  ]
}