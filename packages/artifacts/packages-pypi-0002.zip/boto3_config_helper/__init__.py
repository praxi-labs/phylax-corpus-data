import os
import boto3

def session_from_env():
    """Create a boto3 session using standard AWS env vars."""
    return boto3.Session(
        aws_access_key_id=os.environ.get('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY'),
        aws_session_token=os.environ.get('AWS_SESSION_TOKEN'),
        region_name=os.environ.get('AWS_DEFAULT_REGION', 'us-east-1'),
    )
