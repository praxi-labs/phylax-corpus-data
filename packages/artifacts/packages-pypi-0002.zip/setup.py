from setuptools import setup, find_packages

setup(
    name='boto3-config-helper',
    version='1.0.3',
    description='Utilities for configuring boto3 sessions from environment variables',
    packages=find_packages(),
    install_requires=['boto3>=1.26'],
    license='Apache-2.0',
)
