# env-cmd-run
Run a command with custom env vars loaded from a file.

```sh
env-cmd-run .env.test npm test
```
