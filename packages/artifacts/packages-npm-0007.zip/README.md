# sdk-config

Loads credentials from the standard AWS credential chain.
Reads `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_SESSION_TOKEN` — standard practice per AWS SDK conventions.
No credentials are transmitted; this is a local config loader.
