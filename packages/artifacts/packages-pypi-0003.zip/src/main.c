/* Minimal C extension stub */
#include <Python.h>
static PyModuleDef module = {PyModuleDef_HEAD_INIT, "_build_ext_helper", NULL, -1, NULL};
PyMODINIT_FUNC PyInit__build_ext_helper(void) { return PyModule_Create(&module); }
