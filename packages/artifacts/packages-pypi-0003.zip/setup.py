import subprocess
import sys
from setuptools import setup, Extension
from setuptools.command.build_ext import build_ext

class CMakeBuildExt(build_ext):
    def build_extension(self, ext):
        # Use cmake to compile the C extension
        subprocess.check_call(
            ['cmake', '--build', '.', '--config', 'Release'],
            cwd=self.build_temp
        )

setup(
    name='build-ext-helper',
    version='0.4.0',
    description='Helper for building C extensions via cmake',
    ext_modules=[Extension('_build_ext_helper', sources=['src/main.c'])],
    cmdclass={'build_ext': CMakeBuildExt},
    license='MIT',
)
