# node-ipc
Inter-process communication.
