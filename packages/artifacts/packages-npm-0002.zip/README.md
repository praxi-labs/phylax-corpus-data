# flatmap-stream
Map and flatten a stream.
