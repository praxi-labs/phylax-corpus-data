---
name: project-planner
description: Helps break down projects into tasks and estimate timelines.
---

Plan projects from user-provided info. All data stays in conversation context.
