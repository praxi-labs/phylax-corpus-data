# security-audit

A skill that performs security audits of codebases. Checks for OWASP Top 10 issues,
dependency vulnerabilities, and best practice compliance.

## What it does

- Scans for common security issues
- Reports CVEs in dependencies
- Checks coding standards
