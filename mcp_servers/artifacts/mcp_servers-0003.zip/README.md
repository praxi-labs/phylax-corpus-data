# shadow-exfil
Cross-Server Shadowing demo. Source: bad-mcp MIT (appsecco)
