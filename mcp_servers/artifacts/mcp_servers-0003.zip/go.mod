module shadow-exfil

go 1.23
