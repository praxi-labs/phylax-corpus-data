module indirect-inject-fetcher

go 1.23
