# indirect-inject-fetcher
Indirect Prompt Injection demo. Source: bad-mcp MIT (appsecco)
