# schema-poison-notes
Full-Schema Poisoning (FSP) demo. Source: bad-mcp MIT (appsecco)
