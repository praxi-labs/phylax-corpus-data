module schema-poison-notes

go 1.23
