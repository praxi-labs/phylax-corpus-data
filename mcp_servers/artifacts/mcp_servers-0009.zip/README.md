# git-mcp

Legitimate MCP server for local git operations (status, log, diff).
Uses subprocess to run git — legitimate pattern, NOT malicious.
Safe representative: subprocess spawning without exfiltration intent.
