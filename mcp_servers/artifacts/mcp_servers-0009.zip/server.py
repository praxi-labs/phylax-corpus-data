#!/usr/bin/env python3
"""Legitimate MCP server for git operations. Local only, no network exfiltration."""
import subprocess
import json
import sys
from pathlib import Path

REPO_PATH = sys.argv[1] if len(sys.argv) > 1 else '.'

def git(*args) -> str:
    result = subprocess.run(
        ['git', '-C', REPO_PATH, *args],
        capture_output=True, text=True, timeout=30
    )
    return result.stdout or result.stderr

TOOLS = [
    {'name': 'git_status', 'description': 'Show working tree status',
     'inputSchema': {'type': 'object', 'properties': {}}},
    {'name': 'git_log', 'description': 'Show commit history',
     'inputSchema': {'type': 'object', 'properties': {
         'max_count': {'type': 'integer', 'description': 'Max commits to show'}}}},
    {'name': 'git_diff', 'description': 'Show unstaged changes',
     'inputSchema': {'type': 'object', 'properties': {}}},
]

def handle(message: dict) -> dict | None:
    method = message.get('method'); msg_id = message.get('id')
    if msg_id is None: return None
    if method == 'initialize':
        return {'jsonrpc': '2.0', 'id': msg_id, 'result': {
            'protocolVersion': '2024-11-05',
            'serverInfo': {'name': 'git', 'version': '2.0.0'},
            'capabilities': {'tools': {}}}}
    if method == 'tools/list':
        return {'jsonrpc': '2.0', 'id': msg_id, 'result': {'tools': TOOLS}}
    if method == 'tools/call':
        name = message['params']['name']
        args = message['params'].get('arguments', {})
        if name == 'git_status': output = git('status')
        elif name == 'git_log':
            n = str(args.get('max_count', 10))
            output = git('log', f'--max-count={n}', '--oneline')
        elif name == 'git_diff': output = git('diff')
        else: output = 'unknown tool'
        return {'jsonrpc': '2.0', 'id': msg_id, 'result': {
            'content': [{'type': 'text', 'text': output}]}}
    return {'jsonrpc': '2.0', 'id': msg_id, 'error': {'code': -32601, 'message': 'not found'}}

for line in sys.stdin:
    resp = handle(json.loads(line))
    if resp: print(json.dumps(resp), flush=True)
