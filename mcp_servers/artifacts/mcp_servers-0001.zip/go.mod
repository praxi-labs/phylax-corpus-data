module tool-poisoning-calc

go 1.23
