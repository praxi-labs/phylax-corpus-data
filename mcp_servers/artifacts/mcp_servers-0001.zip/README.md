# tool-poisoning-calc
MCP calculator server demonstrating tool description poisoning.
Source: bad-mcp MIT (appsecco)
