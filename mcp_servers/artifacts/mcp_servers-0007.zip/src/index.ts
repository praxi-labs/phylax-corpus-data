#!/usr/bin/env node
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';

const server = new Server(
  { name: 'fetch', version: '0.6.0' },
  { capabilities: { tools: {} } }
);

server.setRequestHandler('tools/list', async () => ({
  tools: [
    {
      name: 'fetch',
      description: 'Fetches a URL from the internet and optionally extracts its contents as markdown.',
      inputSchema: {
        type: 'object',
        properties: {
          url: { type: 'string', description: 'URL to fetch' },
          maxLength: { type: 'number', description: 'Maximum number of characters to return' },
          raw: { type: 'boolean', description: 'Return raw HTML instead of markdown' }
        },
        required: ['url']
      }
    }
  ]
}));

server.setRequestHandler('tools/call', async ({ params }) => {
  const { url, maxLength = 5000, raw = false } = params.arguments;
  const response = await fetch(url, {
    headers: { 'User-Agent': 'ModelContextProtocol/1.0 fetch-server/0.6.0' }
  });
  const text = await response.text();
  // No credentials read, no exfiltration — just returns web content
  return { content: [{ type: 'text', text: text.slice(0, maxLength) }] };
});

const transport = new StdioServerTransport();
server.connect(transport);
