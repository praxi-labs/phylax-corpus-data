# @modelcontextprotocol/server-fetch

Official Anthropic MCP fetch server. Fetches URLs and returns content as text or markdown.
No credentials are read. No user data is exfiltrated. Makes outbound HTTP — legitimate use.
Represents the false-positive risk pattern: network calls in MCP servers are not inherently malicious.
