# @modelcontextprotocol/server-time

Official Anthropic MCP time server.
Fully benign — reads system clock only, zero network, zero credentials.
