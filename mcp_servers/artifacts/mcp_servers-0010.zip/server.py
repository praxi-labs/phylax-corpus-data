#!/usr/bin/env python3
"""Official MCP time server — returns current time and timezone info.
Zero network calls, zero credential reading, zero exfiltration.
Demonstrates: reading system data without malicious intent.
"""
import json
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

TOOLS = [
    {'name': 'get_current_time', 'description': 'Get the current time in a specified timezone',
     'inputSchema': {'type': 'object', 'properties': {
         'timezone': {'type': 'string', 'description': 'IANA timezone name (e.g. America/New_York)'}},
         'required': ['timezone']}},
    {'name': 'convert_time', 'description': 'Convert time between timezones',
     'inputSchema': {'type': 'object', 'properties': {
         'source_tz': {'type': 'string'}, 'target_tz': {'type': 'string'},
         'time': {'type': 'string', 'description': 'ISO 8601 time string'}},
         'required': ['source_tz', 'target_tz', 'time']}},
]

def handle(message: dict) -> dict | None:
    method = message.get('method'); msg_id = message.get('id')
    if msg_id is None: return None
    if method == 'initialize':
        return {'jsonrpc': '2.0', 'id': msg_id, 'result': {
            'protocolVersion': '2024-11-05',
            'serverInfo': {'name': 'time', 'version': '0.6.0'},
            'capabilities': {'tools': {}}}}
    if method == 'tools/list':
        return {'jsonrpc': '2.0', 'id': msg_id, 'result': {'tools': TOOLS}}
    if method == 'tools/call':
        name = message['params']['name']
        args = message['params'].get('arguments', {})
        if name == 'get_current_time':
            tz = ZoneInfo(args['timezone'])
            now = datetime.now(tz)
            text = json.dumps({'timezone': args['timezone'], 'datetime': now.isoformat(), 'utc_offset': now.strftime('%z')})
        elif name == 'convert_time':
            src = ZoneInfo(args['source_tz']); tgt = ZoneInfo(args['target_tz'])
            t = datetime.fromisoformat(args['time']).replace(tzinfo=src)
            text = json.dumps({'converted': t.astimezone(tgt).isoformat()})
        else:
            text = 'unknown tool'
        return {'jsonrpc': '2.0', 'id': msg_id, 'result': {'content': [{'type': 'text', 'text': text}]}}
    return {'jsonrpc': '2.0', 'id': msg_id, 'error': {'code': -32601, 'message': 'not found'}}

for line in sys.stdin:
    resp = handle(json.loads(line))
    if resp: print(json.dumps(resp), flush=True)
