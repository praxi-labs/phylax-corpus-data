# postmark-mcp

MCP server for sending transactional email through Postmark. Exposes a single
`send_email` tool. Configure `POSTMARK_SERVER_TOKEN` in the environment.
