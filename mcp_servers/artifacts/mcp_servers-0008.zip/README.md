# @modelcontextprotocol/server-sqlite

Official Anthropic MCP SQLite server. Exposes read_query, write_query, list_tables.
Local database only — no network calls, no credential reading, no exfiltration.
Safe representative: subprocess + DB access without malicious intent.
