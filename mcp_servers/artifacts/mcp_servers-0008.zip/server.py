#!/usr/bin/env python3
"""Official MCP SQLite server — reads/writes a local SQLite database.
No credentials read, no network calls, no exfiltration.
Safe MCP server representative.
"""
import sqlite3
import json
import sys
from pathlib import Path

DB_PATH = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('./data.db')

def query(sql: str, params=()) -> list:
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.execute(sql, params)
        if cursor.description:
            cols = [d[0] for d in cursor.description]
            return [dict(zip(cols, row)) for row in cursor.fetchall()]
        return [{'affected': cursor.rowcount}]

TOOLS = [
    {'name': 'read_query', 'description': 'Execute a SELECT query on the SQLite database',
     'inputSchema': {'type': 'object', 'properties': {'query': {'type': 'string'}}, 'required': ['query']}},
    {'name': 'write_query', 'description': 'Execute an INSERT, UPDATE, or DELETE query',
     'inputSchema': {'type': 'object', 'properties': {'query': {'type': 'string'}}, 'required': ['query']}},
    {'name': 'list_tables', 'description': 'List all tables in the database',
     'inputSchema': {'type': 'object', 'properties': {}}},
]

def handle(message: dict) -> dict | None:
    method = message.get('method')
    msg_id = message.get('id')
    if msg_id is None:
        return None
    if method == 'initialize':
        return {'jsonrpc': '2.0', 'id': msg_id, 'result': {
            'protocolVersion': '2024-11-05',
            'serverInfo': {'name': 'sqlite', 'version': '0.6.0'},
            'capabilities': {'tools': {}}}}
    if method == 'tools/list':
        return {'jsonrpc': '2.0', 'id': msg_id, 'result': {'tools': TOOLS}}
    if method == 'tools/call':
        name = message['params']['name']
        args = message['params'].get('arguments', {})
        if name == 'list_tables':
            rows = query("SELECT name FROM sqlite_master WHERE type='table'")
        elif name in ('read_query', 'write_query'):
            rows = query(args['query'])
        else:
            rows = [{'error': 'unknown tool'}]
        return {'jsonrpc': '2.0', 'id': msg_id, 'result': {
            'content': [{'type': 'text', 'text': json.dumps(rows)}]}}
    return {'jsonrpc': '2.0', 'id': msg_id, 'error': {'code': -32601, 'message': 'Method not found'}}

for line in sys.stdin:
    msg = json.loads(line)
    resp = handle(msg)
    if resp:
        print(json.dumps(resp), flush=True)
