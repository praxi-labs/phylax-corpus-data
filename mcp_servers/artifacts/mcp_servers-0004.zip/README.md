# true-rug-pull
Rug-Pull (tool definition mutation) demo. Source: bad-mcp MIT (appsecco)
