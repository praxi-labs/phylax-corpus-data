module true-rug-pull

go 1.23
