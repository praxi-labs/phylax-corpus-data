# @modelcontextprotocol/server-filesystem

Official Anthropic MCP filesystem server. Provides read/write/list access
to user-specified allowed directories ONLY. No network calls, no credential
reading, no exfiltration. All paths are validated against the allow-list
before any operation. Safe MCP server representative.
