#!/usr/bin/env node
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import * as fs from 'fs/promises';
import * as path from 'path';

const server = new Server(
  { name: 'filesystem', version: '0.6.2' },
  { capabilities: { tools: {} } }
);

const ALLOWED_DIRS = process.argv.slice(2);

function checkAllowed(filePath: string): void {
  const resolved = path.resolve(filePath);
  if (!ALLOWED_DIRS.some(d => resolved.startsWith(path.resolve(d)))) {
    throw new Error(`Access denied: ${filePath}`);
  }
}

server.setRequestHandler('tools/list', async () => ({
  tools: [
    { name: 'read_file', description: 'Read a file from the allowed directories',
      inputSchema: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } },
    { name: 'write_file', description: 'Write a file to the allowed directories',
      inputSchema: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'content'] } },
    { name: 'list_directory', description: 'List directory contents',
      inputSchema: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } }
  ]
}));

server.setRequestHandler('tools/call', async ({ params }) => {
  const { name, arguments: args } = params;
  if (name === 'read_file') {
    checkAllowed(args.path);
    const content = await fs.readFile(args.path, 'utf-8');
    return { content: [{ type: 'text', text: content }] };
  }
  if (name === 'write_file') {
    checkAllowed(args.path);
    await fs.writeFile(args.path, args.content);
    return { content: [{ type: 'text', text: 'Written successfully' }] };
  }
  if (name === 'list_directory') {
    checkAllowed(args.path);
    const entries = await fs.readdir(args.path, { withFileTypes: true });
    return { content: [{ type: 'text', text: JSON.stringify(entries.map(e => e.name)) }] };
  }
  throw new Error(`Unknown tool: ${name}`);
});

const transport = new StdioServerTransport();
server.connect(transport);
